# Armas, encantamientos y conjuntos: diseño con el jugador

Estado: diseño en curso. Este documento distingue decisiones acordadas, propuestas y funcionamiento actual. Una propuesta no concede efectos en el juego ni debe aparecer como activa en un tooltip.

## Decisiones acordadas

| Decisión | Acuerdo |
| --- | --- |
| Papel del arma | Mejora estadísticas y añade efectos pequeños. Mantiene una rotación similar y las habilidades de clase. |
| Estadísticas base | Fijas por modelo. Dos copias del mismo modelo tienen las mismas cifras antes de encantarse. |
| Personalización | Encantamiento elegido por el jugador. |
| Aplicación | Pergamino consumible, aplicación garantizada; sustituir un encantamiento elimina el anterior. |
| Activación de efectos especiales | Predecible mediante habilidades, según el acuerdo de la conversación anterior. |
| Equipo inicial | Categoría 0; la siguiente es categoría 1. |
| Piezas de armadura | Cabeza, pecho, manos y piernas. Piernas incluye todo el calzado; no hay ranura separada de pies. |
| Bonificaciones de conjunto | Un bono parcial con 2/4 y otro al completar 4/4; las cifras y efectos quedan por decidir. |
| Atributo principal | Fuerza: guerrero. Agilidad: pícaro y explorador. Intelecto: mago y clérigo. Corpulencia: supervivencia. |
| Colores actuales | Gris, verde, azul, morado, dorado, naranja especial. |

Pendiente: número de encantamientos activos, fabricación y obtención de pergaminos, costes, estadísticas secundarias, fórmulas de los atributos, efectos de conjuntos y cifras de equilibrio. La aplicación garantizada no determina por sí sola las reglas de fabricación.

## Lo que existe hoy

- 88 armas, cinco clases y una habilidad activa por clase, con cinco rangos.
- Arma principal: `power`; varita: además `healing`. Escudo y daga secundaria: `guard`. Libro: `healing`.
- El ataque básico crece con el nivel. El cálculo de las habilidades usa otra fórmula que actualmente no aplica ese mismo crecimiento.
- Alcance y cadencia dependen de la clase, no del modelo de arma.
- 55 conjuntos visuales, cada uno con cuatro piezas de armadura independientes; 33 accesorios. Las piernas incluyen pantalones, rodilleras cuando correspondan y botas.
- Las piezas suman guardia, vida o recurso. No hay bonificaciones por completar conjunto.
- Inventario: identificador de catálogo, cantidad y vínculo. No distingue dos copias encantadas de un modelo.
- No hay encantamientos ni un motor general de efectos persistentes implementados.

Fuentes: `src/data/weapons.ts`, `combat.ts`, `outfits.ts`, `accessories.ts`, `inventory.ts`; `supabase/server/05-weapon-stats.sql` y `07-combat.sql`.

## Paso siguiente: atributos comprensibles

Propuesta pendiente de acordar:

1. Conservar potencia de ataque, potencia de curación y guardia como propiedades principales. El escudo y el libro deben tener una aportación visible propia; la daga secundaria necesita revisar su identidad, porque hoy únicamente reduce daño recibido.
2. Conectar primero los atributos de personaje a sus efectos reales. Está acordado usar fuerza para el guerrero, agilidad para pícaro/explorador, intelecto para mago/clérigo y corpulencia para supervivencia. Todavía no están aprobadas ni implementadas las fórmulas nuevas de potencia: elegir el reparto no cambia por sí solo el daño actual.
3. Empezar con pocas estadísticas secundarias y límites comunes: vida, recurso y eficiencia de habilidades son candidatas. Crítico, celeridad, resistencias y penetración requieren reglas propias antes de introducirse.
4. Cada modelo puede tener un reparto fijo distinto, con un presupuesto comparable a otros de su escalón. Evitar que una opción gane en todas las cifras sin contrapartida dentro del mismo escalón.
5. Pericia, presencia y percepción necesitan sistemas de oficio, comercio y exploración. No llenar el botín de armas con estadísticas que aún no tengan utilidad.

### Una sola escala de combate

Propuesta: obtener primero una potencia efectiva a partir del arma, nivel y atributos. Tanto ataque básico como habilidades deben usar esa base; la habilidad añade su coeficiente y rango. Curación, guardia y supervivencia necesitan sus propias fórmulas explícitas.

Definir antes de equilibrar: orden de sumas y porcentajes, redondeo, mínimos y máximos, alcance, cadencia, coste y recarga. Aplicar los mismos límites a objetos, comida, grupos y conjuntos. No elegir porcentajes aislados sin considerar la suma del equipo completo.

La rareza y el nivel de poder son conceptos distintos aunque el catálogo actual los vincule. Hay que decidir si seguirán unidos. No mostrar el número interno de categoría como si fuera un requisito de nivel.

## Encantamientos: propuesta inicial

Un encantamiento activo por arma como punto de partida, pendiente de confirmar. La fuerza del pergamino debe tener requisitos de equipo para evitar equipar un efecto avanzado en el arma inicial y saltarse la progresión.

Contrato de un encantamiento:

- Identidad y versión; nombre y descripción.
- Armas o ranuras compatibles y requisitos.
- Valor y duración explícitos, límite de acumulación y regla de renovación.
- Activación: habilidad resuelta con éxito y objetivo válido.
- Coste y fuente de obtención del pergamino, todavía por decidir.
- Aplicación garantizada, consumo del pergamino y sustitución del anterior: **acordado**.

Ejemplos para discutir, sin cifras ni efectos activos todavía:

| Clase | Ejemplo de efecto pequeño | Restricción de diseño |
| --- | --- | --- |
| Guerrero | Su habilidad concede una protección breve | No convertirlo en invulnerabilidad permanente |
| Mago | La descarga deja una carga que potencia ligeramente el siguiente ataque básico | Una carga; consumirla no genera otra carga |
| Pícaro | Corte doble aplica un sangrado corto | Una aplicación por uso, no una por cada impacto |
| Clérigo | Curación deja una recuperación breve | Necesita curación efectiva; no activar gratis sobre vida completa |
| Explorador | Disparo preciso marca brevemente a su objetivo | La marca tiene propietario y una regla clara de consumo |

Los pergaminos pueden tener variantes numéricas o de utilidad sin sustituir la habilidad por otra. Debe haber opciones útiles con más de un conjunto. El usuario ha elegido mantener una rotación similar: estos ejemplos no añaden botones ni una rotación obligatoria nueva.

### Reglas que hay que resolver antes de programar efectos

- Varios impactos de una habilidad no multiplican un disparador configurado por uso.
- Un daño periódico o un efecto generado no vuelve a disparar encantamientos por defecto.
- Duración y recargas se miden en tiempo del servidor. Reconectar no reinicia ni concede activaciones.
- Definir si los efectos acumulan intensidad, duración, se renuevan o se sustituyen; nunca dejarlo implícito.
- Resolver retirada del arma, cambio de mapa, muerte, objetivo muerto, desconexión y cambio de conjunto.
- Distinguir daño, curación, absorción y sobrecuración. No presentarlos como equivalentes.
- El disparador consume recursos y genera efectos una sola vez, aunque se reenvíe una solicitud.

## Conjuntos: estructura acordada, efectos pendientes

Acuerdo: cuatro piezas de armadura —cabeza, pecho, manos y piernas con calzado— y bonificaciones con 2/4 y 4/4. Se cuentan piezas de la misma colección y clase. Arma, secundaria y joyas quedan libres para personalización. Así las clases con una o dos piezas de arma tienen el mismo requisito para completar un conjunto.

La unión de piernas y botas está implementada en catálogo, montaje y GLB modular. La migración `17-combined-legwear.sql` conserva las piezas antiguas: cada bota se convierte en unas piernas completas. Si la ranura de piernas estaba ocupada, la conversión vuelve a mochila/banco o queda en la cola de entrega. Es una compensación de una sola vez que conserva cada objeto adquirido.

Propuesta de contenido: un bono pequeño con 2/4 y un bono de identidad con 4/4. El de 4/4 mejoraría modestamente una habilidad existente; no obligaría a una rotación nueva. Los umbrales están aprobados; sus efectos y valores no están implementados ni acordados todavía.

Reglas propuestas:

- Contar ranuras válidas, no cantidad del objeto ni copias en la mochila.
- Contar cada pieza una sola vez y comprobar clase y ranura.
- La colección visual no implica automáticamente un conjunto mecánico; hace falta una definición explícita de bonificaciones.
- Mostrar piezas equipadas y umbrales activos/inactivos, con requisitos exactos.
- Comparar conjunto completo contra combinaciones de piezas. El bono completo debe ser atractivo sin invalidar todo equipo suelto.
- Cambiar piezas no cura ni rellena recurso, no reinicia recargas y no conserva cargas que permitan abusar del cambio.
- Arma, encantamiento y conjunto comparten un presupuesto de potencia; los tres no multiplican indiscriminadamente el daño.

## Sincronía entre sistemas

```mermaid
flowchart TD
  A[Catálogo versionado] --> B[Instancias de equipo y pergaminos]
  B --> C[Equipo válido por clase y ranura]
  C --> D[Estadísticas y conjuntos activos]
  E[Nivel, atributos, comida y grupo] --> D
  D --> F[Habilidad validada por el servidor]
  F --> G[Daño, curación y efectos]
  G --> H[Botín, experiencia y misiones]
  H --> I[Economía y artesanía]
  I --> B
  D --> J[Tooltips y ficha del personaje]
  F --> K[Eventos y estado enviados a los clientes]
```

### Identidad del objeto y transacciones

Antes de aplicar un encantamiento real, añadir una identidad de instancia al equipo no apilable. Modelo conceptual: `instanceId`, `definitionId`, `enchantmentId`, `revision` y propietario. El catálogo conserva los valores base fijos.

Hay que migrar y adaptar conjuntamente: normalización de personaje, inventario, equipo, banco, comercio, botín, persistencia y apariencia remota. El normalizador actual descarta metadatos extra: añadir solo un campo al tooltip o al cliente perdería el encantamiento al guardar.

Aplicación en servidor: validar sesión, propiedad, compatibilidad y revisiones; consumir pergamino y recursos; sustituir encantamiento; recalcular estadísticas; invalidar ofertas de comercio afectadas; confirmar toda la operación de forma atómica. Identificar reintentos para no cobrar dos veces. No enviar al servidor un valor de bonificación calculado por el cliente.

### Una definición, varios consumidores

La definición de objetos y efectos debe alimentar catálogo del servidor, cálculos del cliente, tooltips, ficha y herramienta de equilibrio. Mantener `catalogVersion` y una revisión del estado evita que una respuesta antigua vuelva a equipar un objeto ya sustituido.

Actualmente el catálogo de equipo ya se genera para SQL con `tools/build-weapon-catalog.mjs`, pero varias reglas de combate siguen escritas por separado en TypeScript y SQL. Ampliar la generación y registrar qué versión usa cada cliente antes de añadir más fórmulas duplicadas.

## Tooltips: primera pasada aplicada

- Nombre, rareza y tipo; clase y ranura; colección visual.
- Estadísticas reales, alcance e intervalo del ataque básico para armas principales.
- Descripción breve de construcción y acabado, diferenciada por familia, pieza y colección.
- Vínculo y venta separados de los efectos de combate.
- Sin instrucciones repetidas para equipar, sin repetir la rareza en otra fila y sin categoría numérica ambigua.
- No mostrar encantamientos ni bonificaciones inexistentes como activos.

Cuando se implementen: añadir nivel/requisitos reales, encantamiento aplicado y valores exactos, progreso del conjunto y comparación contextual con lo equipado. Los valores efectivos deben usar la misma fórmula que el combate, distinguiéndolos de valores base. Preservar traducción y navegación accesible.

## Orden de trabajo acordable

1. Decidir estilo de armas, variación base y sustitución de encantamientos: **acordado**.
2. Atributos principales y umbrales 2/4–4/4: **acordados**. Decidir estadísticas secundarias, fórmulas, efectos de conjunto y primer catálogo pequeño de pergaminos.
3. Cerrar fórmulas comunes y presupuesto de potencia; revisar el daño de habilidades frente al básico.
4. Preparar instancias y migración de todas las vías de inventario.
5. Implementar el motor de efectos y una versión jugable de una familia completa, con tooltip fiel al servidor.
6. Extender a las demás clases, obtención de pergaminos, artesanía y recompensas.

No convertir esta hoja en un plan para implementar todos los sistemas MMORPG a la vez. La revisión de dependencias está en [MMORPG-SYSTEMS-REVIEW.md](MMORPG-SYSTEMS-REVIEW.md).
