# Revisión de sistemas MMORPG y dependencias

Fecha: 23 de octubre de 2026. Revisión del código del repositorio, no auditoría del estado de un servidor desplegado. «No localizado» significa que no se ha encontrado un sistema general en los módulos revisados; no demuestra ausencia de cualquier prototipo o herramienta aislada.

## Estado y prioridades

| Sistema | Evidencia actual | Qué necesita para el diseño de equipo | Prioridad |
| --- | --- | --- | --- |
| Cuentas, personajes y sesiones | Servicios de cuenta, presencia y sesiones en `src/services/` y SQL 04/06/08 | Conservar autoridad y propiedad del personaje en todas las operaciones de equipo | Base existente |
| Estadísticas y nivel | `src/data/stats.ts`, `data.ts`, `combat.ts`; SQL 03/06/07 | Conectar atributos a efectos reales y unificar escalado básico/habilidad | P0 |
| Catálogo y equipo | `weapons.ts`, `outfits.ts`, `equipment.ts`; generador SQL y nueve ranuras, con calzado incluido en piernas | Reglas compartidas, requisitos y versiones | P0 |
| Identidad de objetos | `ItemStack` contiene `id`, `count`, `bound`; el normalizador reconstruye solo esos campos | Instancias para conservar encantamientos diferentes en dos copias del mismo modelo | P0 antes de encantar |
| Efectos y estados | Hay comida temporizada y sobrecuración; no se localizó motor general de sangrado, absorción, marcas y cargas | Duración, acumulación, disparadores, origen, recarga e idempotencia | P0 antes de efectos nuevos |
| Comercio y banco | SQL 12/15, revisiones de ofertas, bloqueos y operaciones atómicas | Transportar identidad y encantamiento, conservar vínculo, cancelar aceptaciones al cambiar objetos | P0 al migrar instancias |
| Combate PvE | RPC autoritativa; encuentro tipado como `shadowling`, ligado a la introducción | Enemigos generalizados, encuentros compartidos, participantes y reglas de distancia/objetivos | P1 |
| Grupos y apoyo | Invitaciones, chat y bonificación de reservas; curación activa del clérigo se aplica a sí mismo | Curación a aliados, apoyo, amenaza y reparto de recompensas antes de diseñar roles de grupo completos | P1 |
| Misiones y recompensas | Gnomi e Isberto, XP de bienvenida y botín de historia | Bucle repetible de combate/exploración y recompensas; tablas de botín y fuentes de equipo | P1 |
| Economía | Monedas, vendedor, compra/venta, banco y comercio directo | Entradas y salidas de moneda/materiales, precios de pergaminos y demanda de artesanía | P1 |
| Artesanía y recolección | Atributos y textos las mencionan; no se localizaron recetas/profesiones/recolección generales en los módulos revisados | Recursos, recetas, requisitos y creación transaccional; opciones de obtención de pergaminos | P1 tras cerrar el circuito de objetos |
| Conjuntos y encantamientos | Existen colecciones visuales, sin bonificaciones mecánicas ni encantamientos | Definiciones explícitas, conteo, cálculo y representación consistente | Próxima vertical jugable |
| Muerte y recuperación | Hay salud, muerte, huida y descanso; cama y banco en la introducción | Política única para perder cargas, efectos, encuentros y recompensas en muerte o desconexión | P1 |
| Mundo e instancias | Mapas, viajes, interiores, reloj y presencia compartida | Persistencia de enemigos/recursos, alcance de instancias y sincronía de encuentros | P1 al ampliar PvE |
| Gremios, subastas, correo y reputación | No se localizaron sistemas generales; el gremio narrativo de Gnomi no equivale a gremios de jugadores | Diseñar cuando población y economía justifiquen su coste; cola de entregas si se necesita recuperar objetos | P2, según objetivos |
| PvP | No se localizó un modo general | Decidir si encaja; requiere objetivos, emparejamiento, control y equilibrio específicos | Opcional, posterior |

P0 = dependencia técnica o de coherencia antes de ampliar equipo. P1 = siguiente bucle jugable. P2 = expansión posterior, no requisito obligatorio para que el juego sea divertido.

## Hallazgos que afectan al diseño

### 1. Los atributos no cumplen todavía toda su descripción

`src/data/data.ts` anuncia daño para fuerza, poder mágico para intelecto, resistencia al daño para corpulencia, velocidad para agilidad y efectos de oficio/comercio/exploración. En los cálculos revisados:

- Corpulencia aumenta vida y participa en estamina.
- Intelecto aumenta maná.
- Agilidad participa en estamina; cadencia y movimiento no toman ese atributo en los módulos revisados.
- El daño de combate no usa fuerza ni intelecto, sino arma, nivel o rango.
- No se localizaron las fórmulas de oficio, negociación y hallazgo anunciadas para pericia, presencia y percepción.

Antes de ofrecer atributos en armas hay que cerrar su función y hacer coincidir ficha, creador, combate y servidor. No recomendar invertir puntos basándose en efectos que aún no se aplican.

Decisión tomada durante el diseño: Fuerza para guerrero, Agilidad para pícaro/explorador, Intelecto para mago/clérigo y Corpulencia para supervivencia. El reparto está aprobado; las fórmulas y su implementación siguen pendientes.

### 2. Ataque básico y habilidad no comparten la misma escala de nivel

El básico multiplica potencia por `1 + 0,05 × (nivel − 1)`. Las habilidades ofensivas usan coeficiente, rango y potencia del arma, sin ese factor de nivel. Con espada inicial, a nivel 50 el básico sería 35 y Golpe contundente de rango 1 sería 18 antes de otros cambios. Esto compara fórmulas, no una medición de equilibrio del juego completo.

La habilidad puede dejar de sentirse como una mejora aunque consuma recurso y tenga recarga. Hay que resolverlo antes de añadir porcentajes de encantamiento o conjunto.

### 3. El equipo no tiene identidad por copia

Agregar `enchantmentId` a un objeto no basta: `sanitizeInventory`/`sanitizeEquipment` reconstruyen tres campos; otras rutas comparan o apilan por ID y vínculo. Banco, comercio, botín y guardado deben usar la misma identidad y revisión. De lo contrario se pueden perder o confundir encantamientos entre copias.

### 4. Un grupo social no es todavía combate cooperativo completo

Existen grupos y sus bonificaciones, pero el encuentro de combate revisado se guarda en el personaje y admite `shadowling`. La habilidad del clérigo cura al propio personaje. Antes de prometer conjuntos de tanque o sanador de grupo se necesitan objetivos compartidos, curación a compañeros, participación y reglas de amenaza/recompensas.

### 5. Hay una buena base transaccional que conviene ampliar

Comercio usa revisión de oferta y bloqueos; banco conserva objetos y coordina cambios con comercio. El catálogo de equipo se genera para SQL. Extender esas estructuras existentes permite coordinar encantamiento, materiales, moneda, equipo y ofertas. Revisar el alcance de bloqueos compartidos al crecer la concurrencia: no elegir un bloqueo global por defecto para cada acción de combate.

## Contratos entre sistemas

| Momento | Fuente de verdad | Sistemas que deben reaccionar |
| --- | --- | --- |
| Equipar o retirar | Instancia y ranura validadas en servidor | Estadísticas, conjunto, vida/recurso ajustados sin curación, oferta de comercio, tooltip y apariencia |
| Aplicar pergamino | Una transacción sobre instancia, inventario y costes | Consumo, encantamiento anterior sustituido, revisión, cálculo y confirmación al jugador |
| Usar habilidad | Sesión, objetivo, alcance, coste y recarga validados | Daño/curación, un disparo de efectos elegibles, evento visual y estado resultante |
| Morir un enemigo | Encuentro y participantes confirmados | Botín único, contribución, XP, misión y derechos de recogida |
| Obtener/crear equipo | Fuente de recompensa o receta validada | Identidad única, capacidad de inventario y entrega alternativa si se decide admitirla |
| Cambiar grupo o mapa | Estado de grupo/mundo validado | Reservas, destinatarios de apoyo, efectos permitidos y visibilidad; conservar tiempos de servidor |
| Reintentar o reconectar | Estado y revisiones persistidos | Reenviar resultado sin duplicar pago, recompensa, efecto o fabricación |

## Reglas de equilibrio propuestas

- Un presupuesto común por escalón: arma, atributos, encantamiento, conjunto, comida y grupo deben evaluarse juntos.
- El aumento de reservas también aumenta regeneración porcentual; cualquier nueva bonificación de vida o recurso afecta a la recuperación, no solo al tamaño de barra.
- Si se añaden reducción de coste o de recarga, fijar mínimos y topes compartidos. Evitar bucles de recurso o activaciones infinitas.
- Los efectos de habilidad se activan por uso exitoso salvo excepción explícita; el ataque de dos impactos no duplica automáticamente todos los pergaminos.
- Los conjuntos dan una recompensa por completarlos sin eliminar la opción de combinar piezas. Comparar tanto daño como supervivencia, apoyo, consumo y tiempo para derrotar enemigos.
- El contenido debe aportar motivos para obtener equipo; vender todo el catálogo desde el inicio no sustituye un circuito de recompensas.
- No añadir pérdida de equipo, durabilidad, destrucción al encantar, cuotas diarias ni PvP por inercia: requieren una decisión de experiencia de juego.

## Primera vertical propuesta

Una clase, dos armas de estadísticas fijas, dos pergaminos elegibles, un conjunto de cuatro piezas y un enemigo repetible. Recorrido completo: obtener material o pergamino → aplicar → equipar → combatir → recibir botín → consultar tooltip → guardar/comerciar → reconectar conservando el estado.

Esta vertical depende de las decisiones de atributos y conjunto. Después extender a las cinco clases y a sus fuentes de obtención. Para validar equilibrio cuando se solicite: comparar escenarios completos y fórmulas cliente/servidor, además de revisar duplicación de transacciones y persistencia.

## Referencias externas

- [ESO: bonificaciones de conjunto](https://help.bethesda.net/app/answers/detail/a_id/60388/~/gear-set-bonuses---the-elder-scrolls-online): ejemplo de conteo explícito y combinación de piezas. El número de ranuras de Brumaluz debe decidirse según nuestras clases.
- [ESO: tipos de encantamiento](https://help.elderscrollsonline.com/app/answers/detail/a_id/6119/~/what-are-enchantments-and-what-kind-enchantments-are-there%3F): ejemplo de compatibilidad de encantamientos por tipo de equipo y efecto visible en tooltip.
- [ESO: vista previa de encantamiento](https://help.elderscrollsonline.com/app/answers/detail/a_id/9384/~/why-did-my-enchantment-change-when-i-put-it-on-my-armor%3F): ejemplo de mostrar el resultado antes de aplicar.

Son referencias de presentación y reglas explícitas, no una recomendación de copiar su economía, cantidades o fórmulas. El diseño específico de Brumaluz figura en [WEAPON-SYSTEM-DESIGN.md](WEAPON-SYSTEM-DESIGN.md).
